# Fase 9 — máscara e limpeza

O objetivo desta fase é substituir o preenchimento retangular usado nas primeiras
versões por uma área visualmente mais limitada.

## Estratégia

1. `BalloonAreaDetector` encontra uma área local em torno do OCR.
2. `BalloonMask` cria uma forma oval conservadora.
3. A máscara é restringida por proximidade da cor de fundo estimada.
4. A zona do OCR é mantida na máscara para que o texto original possa ser coberto.
5. O renderer aplica o fundo e a tradução somente dentro dessa máscara.

## Limitação conhecida

Isto ainda não é uma reconstrução semântica do fundo. Se houver desenho exatamente
atrás das letras, pintar com uma única cor pode remover parte desse detalhe.

A próxima revisão deverá comparar esse método com uma estratégia de preenchimento
baseada em pixels vizinhos/inpainting local.
