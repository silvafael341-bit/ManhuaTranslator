# Manhua Translator — Fase 7: Integração

Esta fase conecta o fluxo principal do aplicativo:

1. Seleção de página
2. OCR ML Kit
3. Agrupamento em regiões
4. Identificação do idioma
5. Tradução offline com ML Kit
6. Renderização da tradução sobre a imagem
7. Exibição da página traduzida no leitor

## Tradução

O projeto agora usa `MlKitTranslatorEngine`.

Os modelos de tradução são baixados sob demanda e, depois disso, a tradução é executada no dispositivo.

Idiomas atualmente mapeados:
- Chinês → Português
- Japonês → Português
- Coreano → Português
- Latim/inglês → Português

O download do modelo está condicionado a Wi‑Fi para evitar consumo acidental de dados móveis.

## OCR vertical e rotacionado

O OCR agora tenta as orientações **0°, 90° e 270°**. As caixas detectadas nas imagens rotacionadas são convertidas novamente para as coordenadas da página original.

A seleção do resultado considera:
- confiança média;
- quantidade de caracteres úteis;
- quantidade de blocos;
- presença de caracteres CJK;
- pequena preferência por rotação quando ela realmente produz CJK útil.

Resultados muito sobrepostos e com o mesmo texto são deduplicados.

## Importante

Esta versão ainda não deve ser considerada a versão final de produção.

Próximas etapas:
- melhorar OCR vertical/rotacionado;
- melhorar detecção de balões e máscara de limpeza;
- evitar apagar desenho dentro de balões;
- melhorar quebra de linhas em balões irregulares;
- revisar tradução e tratamento de falhas;
- executar build real e testes;
- só depois preparar GitHub/Codemagic.

## Observação sobre build

O ambiente em que este ZIP foi montado não possui o Gradle instalado, portanto o APK não foi compilado aqui. A configuração foi preparada, mas a compilação real deve ser feita em um ambiente com Gradle/Android SDK, antes de considerar o projeto validado.


## Fase 9 — máscara de balão

O renderer foi alterado para não preencher mais o `Rect` inteiro da região.

Agora:
- cria uma máscara oval conservadora dentro da área detectada;
- limita a máscara à região de fundo localmente compatível;
- inclui uma zona de limpeza em torno do `boundingBox` do OCR;
- aplica o preenchimento somente dentro da máscara;
- desenha a tradução dentro da mesma região mascarada;
- preserva melhor bordas e desenho fora da área do balão.

A solução ainda não é inpainting avançado: fundos com textura complexa,
balões muito irregulares ou texto sobre ilustração podem exigir uma etapa
posterior de reconstrução de fundo.
