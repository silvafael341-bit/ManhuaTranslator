# OCR vertical — Fase 8

O reconhecimento é executado em 0°, 90° e 270°.

## Por que não 180°?
Para páginas de manhua/manga, 180° normalmente não representa uma orientação de leitura útil.
Evitar essa quarta passagem reduz custo de processamento sem eliminar o caso de uso principal.

## Coordenadas
Cada `boundingBox` detectado na imagem rotacionada é transformado para o sistema de coordenadas
da imagem original antes de chegar ao agrupamento e ao renderer.

## Seleção
O resultado não é escolhido apenas por `text.length`. A pontuação combina confiança,
caracteres úteis, número de blocos e sinais de CJK.
