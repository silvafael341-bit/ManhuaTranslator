# Revisão técnica — Fase 10

## Resultado

A arquitetura está coerente para continuar o desenvolvimento, mas a compilação real ainda precisa
ser executada em um ambiente com Android SDK + Gradle.

### Verificações realizadas

- Estrutura Kotlin revisada.
- Pipeline OCR → regiões → tradução → renderer revisado.
- Plugin do Compose presente no Gradle.
- ML Kit OCR e tradução presentes.
- Lifecycle dos recognizers/translators revisado.
- Renderer usando `ImageRenderer` e `TranslatedRegion` do pipeline.
- Manifest/permissões revisados.
- Ausência de `gradlew` registrada como pendência de build.
- Modelo duplicado `TranslatedRegion` removido.
- Memória de Bitmap e páginas grandes identificada como ponto para otimização futura.

## Pendências antes da versão final

1. Executar build real com Gradle/Android SDK.
2. Confirmar as versões exatas das APIs ML Kit no build.
3. Testar OCR em páginas reais CJK horizontais e verticais.
4. Testar renderização em balões brancos, cinza e coloridos.
5. Testar páginas grandes para evitar picos de memória.
6. Melhorar reconstrução de fundo em balões com textura/desenho.
7. Adicionar testes automatizados para mapeamento de coordenadas e quebra de linhas.

## Decisão

Não avançar para GitHub/Codemagic como se o projeto já estivesse validado.
Primeiro deve existir pelo menos um build real bem-sucedido e uma rodada de testes funcionais.
