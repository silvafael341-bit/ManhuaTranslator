package com.manhuatranslator.domain.rendering

import android.graphics.Rect
import com.manhuatranslator.domain.pipeline.TranslatedRegion

data class RenderedPage(
    val bitmap: android.graphics.Bitmap,
    val renderedRegions: Int,
    val skippedRegions: Int
)

data class TextLayout(
    val lines: List<String>,
    val fontSizePx: Float,
    val bounds: Rect
)

data class BalloonArea(
    val bounds: Rect,
    val centerX: Float,
    val centerY: Float,
    val backgroundArgb: Int,
    val confidence: Float
)
