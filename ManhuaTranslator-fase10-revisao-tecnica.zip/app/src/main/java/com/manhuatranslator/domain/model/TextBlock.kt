package com.manhuatranslator.domain.model

import android.graphics.Rect

data class TextBlock(
    val id: String,
    val text: String,
    val bounds: Rect,
    val confidence: Float,
    val language: String? = null,
    val vertical: Boolean = false
)
