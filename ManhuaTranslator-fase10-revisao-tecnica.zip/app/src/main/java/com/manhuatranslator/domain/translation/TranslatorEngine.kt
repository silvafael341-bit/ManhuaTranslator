package com.manhuatranslator.domain.translation

interface TranslatorEngine {
    suspend fun translate(request: TranslationRequest): TranslationResult
    fun close()
}
