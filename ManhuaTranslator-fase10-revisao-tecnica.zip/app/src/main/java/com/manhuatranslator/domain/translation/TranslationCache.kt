package com.manhuatranslator.domain.translation

/**
 * Small in-memory cache for the current process.
 * A persistent cache can replace this later without changing TranslatorEngine.
 */
class TranslationCache {
    private val values = LinkedHashMap<String, TranslationResult>(128, 0.75f, true)

    @Synchronized
    fun get(request: TranslationRequest): TranslationResult? =
        values[key(request)]?.copy(fromCache = true)

    @Synchronized
    fun put(result: TranslationResult) {
        values[key(TranslationRequest(result.originalText, result.sourceLanguage, result.targetLanguage))] =
            result.copy(fromCache = false)
        if (values.size > 256) {
            val first = values.entries.firstOrNull()?.key
            if (first != null) values.remove(first)
        }
    }

    @Synchronized
    fun clear() = values.clear()

    private fun key(request: TranslationRequest): String =
        "${request.sourceLanguage}|${request.targetLanguage}|${request.text.trim()}"
}
