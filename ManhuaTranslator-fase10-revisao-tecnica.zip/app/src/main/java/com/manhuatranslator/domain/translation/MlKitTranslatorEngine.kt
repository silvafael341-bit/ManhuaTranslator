package com.manhuatranslator.domain.translation

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

/**
 * Real on-device translator backed by Google ML Kit Translation.
 * Models are downloaded only when first needed.
 */
class MlKitTranslatorEngine : TranslatorEngine {

    private val translators = mutableMapOf<Pair<String, String>, Translator>()

    override suspend fun translate(request: TranslationRequest): TranslationResult {
        val source = normalizeLanguage(request.sourceLanguage)
        val target = normalizeLanguage(request.targetLanguage)

        require(source != target) {
            "Idioma de origem e destino são iguais: $source"
        }

        val translator = translators.getOrPut(source to target) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(target)
                .build()
            Translation.getClient(options)
        }

        val conditions = DownloadConditions.Builder()
            .requireWifi()
            .build()

        translator.downloadModelIfNeeded(conditions).await()

        val translated = translator.translate(request.text).await().trim()
        if (translated.isBlank()) {
            error("O tradutor retornou texto vazio.")
        }

        return TranslationResult(
            originalText = request.text,
            translatedText = translated,
            sourceLanguage = source,
            targetLanguage = target
        )
    }

    override fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
    }

    private fun normalizeLanguage(language: String): String {
        return when (language.lowercase()) {
            "zh", "zh-cn", "zh-hans", "chinese" -> "zh"
            "ja", "ja-jp", "japanese" -> "ja"
            "ko", "ko-kr", "korean" -> "ko"
            "en", "en-us", "english", "latin" -> "en"
            "pt", "pt-br", "portuguese" -> "pt"
            else -> error("Idioma não suportado pelo tradutor: $language")
        }
    }
}
