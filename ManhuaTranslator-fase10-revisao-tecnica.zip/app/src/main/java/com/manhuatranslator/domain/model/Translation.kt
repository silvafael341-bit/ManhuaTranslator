package com.manhuatranslator.domain.model

data class Translation(
    val original: String,
    val translated: String,
    val sourceLanguage: String,
    val targetLanguage: String = "pt"
)
