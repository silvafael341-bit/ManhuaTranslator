package com.manhuatranslator.domain.rendering

import android.graphics.Bitmap
import com.manhuatranslator.domain.pipeline.TranslatedRegion

interface ImageRenderer {
    suspend fun render(
        original: Bitmap,
        regions: List<TranslatedRegion>
    ): Bitmap
}
