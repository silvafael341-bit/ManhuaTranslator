package com.manhuatranslator.domain.translation

/**
 * Decorator that prevents repeated translations of identical text.
 */
class CachedTranslatorEngine(
    private val delegate: TranslatorEngine,
    private val cache: TranslationCache = TranslationCache()
) : TranslatorEngine {

    override suspend fun translate(request: TranslationRequest): TranslationResult {
        cache.get(request)?.let { return it }

        val result = delegate.translate(request)
        if (result.translatedText.isNotBlank()) {
            cache.put(result)
        }
        return result
    }

    fun clearCache() = cache.clear()

    override fun close() = delegate.close()
}
