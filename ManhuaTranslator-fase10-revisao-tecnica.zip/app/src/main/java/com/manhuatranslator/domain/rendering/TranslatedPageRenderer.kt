package com.manhuatranslator.domain.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Region
import android.graphics.Typeface
import com.manhuatranslator.domain.pipeline.TranslatedRegion

class TranslatedPageRenderer(
    private val balloonDetector: BalloonAreaDetector = BalloonAreaDetector(),
    private val maskBuilder: BalloonMask = BalloonMask(),
    private val layoutEngine: TextLayoutEngine = TextLayoutEngine()
) : ImageRenderer {

    fun renderPage(source: Bitmap, regions: List<TranslatedRegion>): RenderedPage {
        val output = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)

        var rendered = 0
        var skipped = 0

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            color = Color.BLACK
        }

        regions.forEach { translated ->
            val translation = translated.translation?.translatedText?.trim()
            if (translation.isNullOrEmpty()) {
                skipped++
                return@forEach
            }

            val balloon = balloonDetector.detect(output, translated.region.boundingBox)
            if (balloon == null) {
                skipped++
                return@forEach
            }

            val mask = maskBuilder.create(
                bitmap = output,
                textBounds = translated.region.boundingBox,
                balloon = balloon
            )
            if (mask == null || mask.isEmpty) {
                skipped++
                return@forEach
            }

            // Clean only the masked region. This replaces the old full
            // rectangle fill and therefore reduces damage to line-art.
            val save = canvas.save()
            canvas.clipRegion(mask)

            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = balloon.backgroundArgb
                style = Paint.Style.FILL
            }
            canvas.drawColor(balloon.backgroundArgb)

            val layout = layoutEngine.fit(
                text = translation,
                area = balloon.bounds,
                paint = textPaint
            )

            if (layout == null) {
                canvas.restoreToCount(save)
                skipped++
                return@forEach
            }

            textPaint.textSize = layout.fontSizePx
            textPaint.color = chooseTextColor(balloon.backgroundArgb)

            val metrics = textPaint.fontMetrics
            val lineHeight = metrics.bottom - metrics.top
            val totalHeight = layout.lines.size * lineHeight
            var baseline = balloon.centerY - totalHeight / 2f - metrics.top

            layout.lines.forEach { line ->
                canvas.drawText(line, balloon.centerX, baseline, textPaint)
                baseline += lineHeight
            }

            canvas.restoreToCount(save)
            rendered++
        }

        return RenderedPage(output, rendered, skipped)
    }

    override suspend fun render(
        original: Bitmap,
        regions: List<TranslatedRegion>
    ): Bitmap = renderPage(original, regions).bitmap

    private fun chooseTextColor(background: Int): Int {
        val luminance =
            0.299 * Color.red(background) +
                0.587 * Color.green(background) +
                0.114 * Color.blue(background)
        return if (luminance > 150) Color.BLACK else Color.WHITE
    }
}
