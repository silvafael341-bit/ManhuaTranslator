package com.manhuatranslator.domain.detection

import android.graphics.Rect
import com.manhuatranslator.domain.ocr.OcrBlock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative spatial grouper for manga/manhua OCR.
 *
 * It favors separation over aggressive merging:
 * - blocks must be close relative to their dimensions;
 * - there must be meaningful horizontal/vertical alignment;
 * - very large gaps are rejected;
 * - overlapping/nearby blocks can merge;
 * - the final region is ordered in reading order.
 *
 * Balloon-shape detection is intentionally kept separate so this component
 * only decides which OCR blocks belong together.
 */
class TextRegionGrouper(
    private val maxGapFactor: Float = 1.35f,
    private val maxRegionExpansionFactor: Float = 2.5f
) {

    fun group(blocks: List<OcrBlock>): List<TextRegion> {
        val valid = blocks
            .filter { it.text.isNotBlank() && it.boundingBox.width() > 0 && it.boundingBox.height() > 0 }
            .map { it.copy(text = it.text.trim()) }

        if (valid.isEmpty()) return emptyList()

        val groups = mutableListOf<MutableList<OcrBlock>>()

        for (block in valid.sortedWith(compareBy({ it.boundingBox.top }, { it.boundingBox.left }))) {
            var bestIndex = -1
            var bestScore = Float.MAX_VALUE

            for (i in groups.indices) {
                val group = groups[i]
                val score = connectionScore(block, group)
                if (score >= 0f && score < bestScore && canAccept(group, block)) {
                    bestIndex = i
                    bestScore = score
                }
            }

            if (bestIndex >= 0) {
                groups[bestIndex].add(block)
            } else {
                groups.add(mutableListOf(block))
            }
        }

        // A second conservative pass can join transitive lines only when
        // both neighboring blocks satisfy the same spatial constraints.
        var changed: Boolean
        do {
            changed = false
            outer@ for (i in groups.indices) {
                for (j in i + 1 until groups.size) {
                    if (groups[i].all { a -> groups[j].all { b -> connectionScore(a, listOf(b)) >= 0f } }
                        && canMergeGroups(groups[i], groups[j])) {
                        groups[i].addAll(groups[j])
                        groups.removeAt(j)
                        changed = true
                        break@outer
                    }
                }
            }
        } while (changed)

        return groups
            .map { makeRegion(it) }
            .sortedWith(compareBy({ it.boundingBox.top }, { it.boundingBox.left }))
    }

    private fun connectionScore(block: OcrBlock, group: List<OcrBlock>): Float {
        var best = Float.POSITIVE_INFINITY
        for (other in group) {
            if (block === other) continue

            val a = block.boundingBox
            val b = other.boundingBox

            val horizontalGap = when {
                a.right < b.left -> b.left - a.right
                b.right < a.left -> a.left - b.right
                else -> 0
            }
            val verticalGap = when {
                a.bottom < b.top -> b.top - a.bottom
                b.bottom < a.top -> a.top - b.bottom
                else -> 0
            }

            val overlapX = overlap(a.left, a.right, b.left, b.right)
            val overlapY = overlap(a.top, a.bottom, b.top, b.bottom)

            val alignedX = overlapX >= min(a.width(), b.width()) * 0.18f
            val alignedY = overlapY >= min(a.height(), b.height()) * 0.18f

            val horizontalLimit = max(a.height(), b.height()) * maxGapFactor
            val verticalLimit = max(a.width(), b.width()) * maxGapFactor

            val sameRow = horizontalGap <= horizontalLimit && alignedY
            val sameColumn = verticalGap <= verticalLimit && alignedX
            val touching = horizontalGap == 0 && verticalGap == 0

            if (sameRow || sameColumn || touching) {
                val normalized = (horizontalGap + verticalGap).toFloat() /
                    max(1, min(max(a.width(), b.width()), max(a.height(), b.height())))
                best = min(best, normalized)
            }
        }
        return if (best.isFinite()) best else -1f
    }

    private fun canAccept(group: List<OcrBlock>, block: OcrBlock): Boolean {
        val bounds = groupBounds(group)
        val candidate = union(bounds, block.boundingBox)
        val maxWidth = max(bounds.width(), block.boundingBox.width()) * maxRegionExpansionFactor
        val maxHeight = max(bounds.height(), block.boundingBox.height()) * maxRegionExpansionFactor
        return candidate.width() <= maxWidth && candidate.height() <= maxHeight
    }

    private fun canMergeGroups(a: List<OcrBlock>, b: List<OcrBlock>): Boolean {
        val ba = groupBounds(a)
        val bb = groupBounds(b)
        val scoreA = a.minOfOrNull { connectionScore(it, b) } ?: -1f
        val scoreB = b.minOfOrNull { connectionScore(it, a) } ?: -1f
        if (scoreA < 0f || scoreB < 0f) return false

        val merged = union(ba, bb)
        val widthLimit = max(ba.width(), bb.width()) * maxRegionExpansionFactor
        val heightLimit = max(ba.height(), bb.height()) * maxRegionExpansionFactor
        return merged.width() <= widthLimit && merged.height() <= heightLimit
    }

    private fun makeRegion(blocks: List<OcrBlock>): TextRegion {
        val ordered = blocks.sortedWith(
            compareBy<OcrBlock>({ it.boundingBox.top }, { it.boundingBox.left })
        )
        val text = ordered.joinToString(" ") { it.text.trim() }
        val confidence = ordered.mapNotNull { it.confidence }.average()
            .takeIf { !it.isNaN() }?.toFloat() ?: 0f

        return TextRegion(
            blocks = ordered,
            boundingBox = groupBounds(ordered),
            originalText = text,
            confidence = confidence
        )
    }

    private fun groupBounds(blocks: List<OcrBlock>): Rect {
        var result = Rect(blocks.first().boundingBox)
        for (i in 1 until blocks.size) {
            result = union(result, blocks[i].boundingBox)
        }
        return result
    }

    private fun union(a: Rect, b: Rect): Rect =
        Rect(min(a.left, b.left), min(a.top, b.top), max(a.right, b.right), max(a.bottom, b.bottom))

    private fun overlap(a1: Int, a2: Int, b1: Int, b2: Int): Int =
        max(0, min(a2, b2) - max(a1, b1))
}
