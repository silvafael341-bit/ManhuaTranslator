package com.manhuatranslator.domain.detection

import com.manhuatranslator.domain.ocr.OcrBlock

interface TextRegionDetector {
    fun detect(blocks: List<OcrBlock>): List<TextRegion>
}

class DefaultTextRegionDetector(
    private val grouper: TextRegionGrouper = TextRegionGrouper()
) : TextRegionDetector {
    override fun detect(blocks: List<OcrBlock>): List<TextRegion> = grouper.group(blocks)
}
