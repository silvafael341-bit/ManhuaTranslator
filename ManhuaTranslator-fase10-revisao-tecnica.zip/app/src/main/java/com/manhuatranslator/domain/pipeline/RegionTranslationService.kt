package com.manhuatranslator.domain.pipeline

import com.manhuatranslator.domain.detection.TextRegion
import com.manhuatranslator.domain.translation.TranslationFailure
import com.manhuatranslator.domain.translation.TranslationRequest
import com.manhuatranslator.domain.translation.TranslationResult
import com.manhuatranslator.domain.translation.TranslatorEngine

data class TranslatedRegion(
    val region: TextRegion,
    val translation: TranslationResult? = null,
    val failure: TranslationFailure? = null
)

class RegionTranslationService(
    private val translator: TranslatorEngine
) {
    suspend fun translate(
        regions: List<TextRegion>,
        sourceLanguage: String,
        targetLanguage: String = "pt"
    ): List<TranslatedRegion> {
        return regions.map { region ->
            try {
                val result = translator.translate(
                    TranslationRequest(
                        text = region.originalText,
                        sourceLanguage = sourceLanguage,
                        targetLanguage = targetLanguage
                    )
                )
                if (result.translatedText.isBlank()) {
                    TranslatedRegion(
                        region = region,
                        failure = TranslationFailure(region.originalText, "Tradução vazia.")
                    )
                } else {
                    TranslatedRegion(region = region, translation = result)
                }
            } catch (e: Exception) {
                TranslatedRegion(
                    region = region,
                    failure = TranslationFailure(
                        region.originalText,
                        e.message ?: "Falha desconhecida na tradução."
                    )
                )
            }
        }
    }
}
