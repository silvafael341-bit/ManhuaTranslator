package com.manhuatranslator.domain.detection

import android.graphics.Rect
import com.manhuatranslator.domain.ocr.OcrBlock

/**
 * A conservative group of OCR blocks that likely belongs to the same
 * speech/text region. This object becomes the unit for translation and
 * rendering.
 */
data class TextRegion(
    val blocks: List<OcrBlock>,
    val boundingBox: Rect,
    val originalText: String,
    val confidence: Float
)
