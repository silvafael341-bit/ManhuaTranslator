package com.manhuatranslator.domain.rendering

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Finds a conservative rectangular working area around an OCR region.
 *
 * This is intentionally not a flood-fill of the whole page. It samples
 * pixels around the OCR box, estimates a background color, then expands
 * only while neighboring pixels remain sufficiently similar.
 *
 * The renderer can later replace this with a contour/mask detector without
 * changing its public API.
 */
class BalloonAreaDetector {

    fun detect(bitmap: Bitmap, textBounds: Rect): BalloonArea? {
        if (textBounds.width() <= 0 || textBounds.height() <= 0) return null

        val safe = Rect(
            max(0, textBounds.left),
            max(0, textBounds.top),
            min(bitmap.width, textBounds.right),
            min(bitmap.height, textBounds.bottom)
        )
        if (safe.width() < 2 || safe.height() < 2) return null

        val bg = estimateBackground(bitmap, safe)
        val color = bg ?: return null

        val expansionX = max(16, safe.width() * 3 / 5)
        val expansionY = max(16, safe.height() * 3 / 5)

        val candidate = Rect(
            max(0, safe.left - expansionX),
            max(0, safe.top - expansionY),
            min(bitmap.width, safe.right + expansionX),
            min(bitmap.height, safe.bottom + expansionY)
        )

        val refined = refine(bitmap, candidate, color)
        return BalloonArea(
            bounds = refined,
            centerX = refined.exactCenterX(),
            centerY = refined.exactCenterY(),
            backgroundArgb = color,
            confidence = 0.78f
        )
    }

    private fun estimateBackground(bitmap: Bitmap, r: Rect): Int? {
        val samples = mutableListOf<Int>()
        val margin = max(2, min(r.width(), r.height()) / 6)

        val points = listOf(
            r.left + margin to r.top + margin,
            r.right - margin - 1 to r.top + margin,
            r.left + margin to r.bottom - margin - 1,
            r.right - margin - 1 to r.bottom - margin - 1,
            r.centerX() to r.top + margin,
            r.centerX() to r.bottom - margin - 1
        )

        for ((x, y) in points) {
            if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
                samples += bitmap.getPixel(x, y)
            }
        }
        return samples
            .groupBy { quantize(it) }
            .maxByOrNull { it.value.size }
            ?.value
            ?.firstOrNull()
    }

    private fun quantize(c: Int): Int {
        val r = Color.red(c) / 16
        val g = Color.green(c) / 16
        val b = Color.blue(c) / 16
        return (r shl 8) or (g shl 4) or b
    }

    private fun refine(bitmap: Bitmap, start: Rect, bg: Int): Rect {
        var left = start.left
        var top = start.top
        var right = start.right
        var bottom = start.bottom

        // Conservative inward trimming based on border strips.
        while (left < right - 2 && borderDifference(bitmap, left, top, right, bottom, bg) > 0.72) left++
        while (top < bottom - 2 && borderDifference(bitmap, left, top, right, bottom, bg) > 0.72) top++
        while (right > left + 2 && borderDifference(bitmap, left, top, right, bottom, bg) > 0.72) right--
        while (bottom > top + 2 && borderDifference(bitmap, left, top, right, bottom, bg) > 0.72) bottom--

        return Rect(left, top, right, bottom)
    }

    private fun borderDifference(bitmap: Bitmap, left: Int, top: Int, right: Int, bottom: Int, bg: Int): Double {
        var total = 0
        var different = 0
        val points = listOf(
            left to top, right - 1 to top, left to bottom - 1, right - 1 to bottom - 1,
            (left + right) / 2 to top, (left + right) / 2 to bottom - 1,
            left to (top + bottom) / 2, right - 1 to (top + bottom) / 2
        )
        for ((x, y) in points) {
            if (x !in 0 until bitmap.width || y !in 0 until bitmap.height) continue
            total++
            if (colorDistance(bitmap.getPixel(x, y), bg) > 70) different++
        }
        return if (total == 0) 1.0 else different.toDouble() / total
    }

    private fun colorDistance(a: Int, b: Int): Int {
        return abs(Color.red(a) - Color.red(b)) +
            abs(Color.green(a) - Color.green(b)) +
            abs(Color.blue(a) - Color.blue(b))
    }
}
