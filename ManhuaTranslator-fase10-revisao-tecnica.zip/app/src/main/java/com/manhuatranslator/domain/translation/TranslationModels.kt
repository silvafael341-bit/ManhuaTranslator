package com.manhuatranslator.domain.translation

data class TranslationRequest(
    val text: String,
    val sourceLanguage: String,
    val targetLanguage: String = "pt"
)

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val sourceLanguage: String,
    val targetLanguage: String,
    val fromCache: Boolean = false
)

data class TranslationFailure(
    val originalText: String,
    val reason: String
)
