package com.manhuatranslator.domain.rendering

import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.max

class TextLayoutEngine {

    fun fit(
        text: String,
        area: Rect,
        paint: Paint,
        minSizePx: Float = 12f,
        maxSizePx: Float = 64f,
        horizontalPaddingPx: Float = 12f,
        verticalPaddingPx: Float = 12f
    ): TextLayout? {
        val availableWidth = max(1f, area.width() - horizontalPaddingPx * 2)
        val availableHeight = max(1f, area.height() - verticalPaddingPx * 2)

        var size = min(maxSizePx, max(minSizePx, area.height() * 0.16f))

        while (size >= minSizePx) {
            paint.textSize = size
            val lines = wrap(text.trim(), paint, availableWidth)
            val lineHeight = paint.fontMetrics.run { bottom - top }
            val totalHeight = lines.size * lineHeight

            if (totalHeight <= availableHeight) {
                val maxLineWidth = lines.maxOfOrNull { paint.measureText(it) } ?: 0f
                if (maxLineWidth <= availableWidth) {
                    return TextLayout(
                        lines = lines,
                        fontSizePx = size,
                        bounds = Rect(area)
                    )
                }
            }
            size -= 1f
        }

        return null
    }

    private fun wrap(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return emptyList()

        val tokens = if (text.any { it.isWhitespace() }) {
            text.split(Regex("\\s+"))
        } else {
            text.map { it.toString() }
        }

        val lines = mutableListOf<String>()
        var current = ""

        for (token in tokens) {
            val candidate = if (current.isEmpty()) token else "$current $token"
            if (paint.measureText(candidate) <= maxWidth) {
                current = candidate
            } else {
                if (current.isNotEmpty()) lines += current
                if (paint.measureText(token) <= maxWidth) {
                    current = token
                } else {
                    // Very long word/CJK run: break by character.
                    var chunk = ""
                    for (ch in token) {
                        val next = chunk + ch
                        if (paint.measureText(next) <= maxWidth) {
                            chunk = next
                        } else {
                            if (chunk.isNotEmpty()) lines += chunk
                            chunk = ch.toString()
                        }
                    }
                    current = chunk
                }
            }
        }
        if (current.isNotEmpty()) lines += current
        return lines
    }
}
