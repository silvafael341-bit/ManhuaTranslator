package com.manhuatranslator.domain.ocr

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.tasks.await
import kotlin.math.max
import kotlin.math.min

class MlKitOcrEngine : OcrEngine {

    private val recognizers = listOf(
        OcrRecognizer(OcrScript.CHINESE, com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions.Builder().build()),
        OcrRecognizer(OcrScript.JAPANESE, com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions.Builder().build()),
        OcrRecognizer(OcrScript.KOREAN, com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions.Builder().build()),
        OcrRecognizer(OcrScript.LATIN, com.google.mlkit.vision.text.latin.TextRecognizerOptions.Builder().build())
    )

    override suspend fun recognize(bitmap: Bitmap): OcrPageResult {
        val candidates = mutableListOf<Candidate>()

        for (rotation in listOf(0, 90, 270)) {
            val rotated = if (rotation == 0) bitmap else rotate(bitmap, rotation)
            try {
                for (recognizer in recognizers) {
                    val image = InputImage.fromBitmap(rotated, 0)
                    val result = recognizer.client.process(image).await()
                    val blocks = result.textBlocks
                        .flatMap { block -> block.lines.mapNotNull { line ->
                            val text = line.text.trim()
                            if (text.isBlank()) null else {
                                val box = mapRectToOriginal(
                                    line.boundingBox ?: return@mapNotNull null,
                                    rotation,
                                    bitmap.width,
                                    bitmap.height
                                )
                                OcrBlock(
                                    text = text,
                                    boundingBox = box,
                                    confidence = line.elements
                                        .mapNotNull { it.confidence }
                                        .takeIf { it.isNotEmpty() }
                                        ?.average()
                                        ?: 0.5f
                                )
                            }
                        } }
                    candidates += Candidate(recognizer.script, rotation, blocks, score(recognizer.script, rotation, blocks))
                }
            } finally {
                if (rotated !== bitmap) rotated.recycle()
            }
        }

        val best = candidates.maxByOrNull { it.score }
            ?: return OcrPageResult(OcrScript.UNKNOWN, emptyList())

        val selected = deduplicate(best.blocks)
        return OcrPageResult(
            script = best.script,
            blocks = selected.sortedWith(compareBy({ it.boundingBox.top }, { it.boundingBox.left }))
        )
    }

    override fun close() {
        recognizers.forEach { it.client.close() }
    }

    private fun score(
        script: OcrScript,
        rotation: Int,
        blocks: List<OcrBlock>
    ): Double {
        if (blocks.isEmpty()) return -1000.0

        val usefulChars = blocks.sumOf { it.text.count { c -> !c.isWhitespace() } }
        val avgConfidence = blocks.map { it.confidence }.average()
        val cjkChars = blocks.sumOf { block ->
            block.text.count { c ->
                c.code in 0x3040..0x30FF ||
                c.code in 0x3400..0x9FFF ||
                c.code in 0xAC00..0xD7AF
            }
        }

        val cjkBonus = if (script != OcrScript.LATIN) cjkChars * 1.8 else 0.0
        val confidenceScore = avgConfidence * 90.0
        val blockScore = min(blocks.size, 30) * 3.0

        // Rotated CJK recognition gets a small bonus only when it actually
        // produces useful text, preventing rotation from winning by default.
        val rotationBonus = if (rotation != 0 && script != OcrScript.LATIN && cjkChars >= 2) 10.0 else 0.0

        return usefulChars + confidenceScore + blockScore + cjkBonus + rotationBonus
    }

    private fun deduplicate(blocks: List<OcrBlock>): List<OcrBlock> {
        return blocks
            .sortedByDescending { quality(it) }
            .fold(mutableListOf()) { selected, candidate ->
                val duplicate = selected.any { existing ->
                    overlapRatio(existing.boundingBox, candidate.boundingBox) > 0.72f &&
                        normalize(existing.text) == normalize(candidate.text)
                }
                if (!duplicate) selected += candidate
                selected
            }
            .sortedWith(compareBy({ it.boundingBox.top }, { it.boundingBox.left }))
    }

    private fun quality(block: OcrBlock): Double =
        block.confidence * 100.0 + block.text.length.coerceAtMost(30)

    private fun normalize(value: String): String =
        value.lowercase().replace(Regex("\\s+"), "")

    private fun overlapRatio(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f

        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val smaller = min(
            (a.width().toLong() * a.height()),
            (b.width().toLong() * b.height())
        )
        return if (smaller == 0L) 0f else intersection.toFloat() / smaller.toFloat()
    }

    private fun rotate(source: Bitmap, degrees: Int): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(
            source, 0, 0, source.width, source.height, matrix, true
        )
    }

    private fun mapRectToOriginal(
        rect: Rect,
        rotation: Int,
        originalWidth: Int,
        originalHeight: Int
    ): Rect {
        if (rotation == 0) return Rect(rect)

        // Rotation mapping is performed from the rotated image coordinate
        // system back into the original bitmap coordinate system.
        val points = arrayOf(
            floatArrayOf(rect.left.toFloat(), rect.top.toFloat()),
            floatArrayOf(rect.right.toFloat(), rect.top.toFloat()),
            floatArrayOf(rect.left.toFloat(), rect.bottom.toFloat()),
            floatArrayOf(rect.right.toFloat(), rect.bottom.toFloat())
        )

        val rw = if (rotation == 90 || rotation == 270) originalHeight else originalWidth
        val rh = if (rotation == 90 || rotation == 270) originalWidth else originalHeight

        val mapped = points.map { p ->
            val x = p[0]
            val y = p[1]
            if (rotation == 90) {
                floatArrayOf(y, rw - x)
            } else {
                floatArrayOf(rh - y, x)
            }
        }

        val left = mapped.minOf { it[0] }.toInt().coerceIn(0, originalWidth)
        val top = mapped.minOf { it[1] }.toInt().coerceIn(0, originalHeight)
        val right = mapped.maxOf { it[0] }.toInt().coerceIn(0, originalWidth)
        val bottom = mapped.maxOf { it[1] }.toInt().coerceIn(0, originalHeight)

        return Rect(left, top, right, bottom)
    }

    private data class Candidate(
        val script: OcrScript,
        val rotation: Int,
        val blocks: List<OcrBlock>,
        val score: Double
    )

    private data class OcrRecognizer(
        val script: OcrScript,
        val client: com.google.mlkit.vision.text.TextRecognizer
    )
}
