package com.manhuatranslator.domain.translation

/**
 * Safe placeholder used until the real ML Kit/on-device translation provider
 * is connected. It never pretends a failed translation is a translation.
 */
class OfflinePlaceholderTranslator : TranslatorEngine {
    override suspend fun translate(request: TranslationRequest): TranslationResult {
        throw UnsupportedOperationException(
            "Nenhum modelo de tradução foi configurado para ${request.sourceLanguage}->${request.targetLanguage}."
        )
    }

    override fun close() = Unit
}
