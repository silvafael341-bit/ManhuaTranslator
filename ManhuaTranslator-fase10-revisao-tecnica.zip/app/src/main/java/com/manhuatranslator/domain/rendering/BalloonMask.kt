package com.manhuatranslator.domain.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Region
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Creates a conservative mask around an OCR region.
 *
 * The mask is intentionally based on the estimated local background and
 * an ellipse/rounded working shape. It is not a full image inpainting
 * algorithm, so line-art preservation is preferred over aggressive cleanup.
 */
class BalloonMask {

    fun create(
        bitmap: Bitmap,
        textBounds: Rect,
        balloon: BalloonArea
    ): Region? {
        val bounds = balloon.bounds
        if (bounds.width() < 4 || bounds.height() < 4) return null

        val mask = Region()
        val path = android.graphics.Path()

        // Most manga/manhua balloons are approximately oval/rounded.
        // The bounds are already conservative, so this shape avoids
        // painting an arbitrary page-wide rectangle.
        val insetX = max(1f, bounds.width() * 0.03f)
        val insetY = max(1f, bounds.height() * 0.03f)
        val oval = android.graphics.RectF(
            bounds.left + insetX,
            bounds.top + insetY,
            bounds.right - insetX,
            bounds.bottom - insetY
        )
        path.addOval(oval, android.graphics.Path.Direction.CW)
        mask.setPath(path, Region(bounds))

        // Intersect with the local background-compatible area. This makes
        // the mask shrink away from strong borders/line art.
        val compatible = Region()
        val rowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val tolerance = max(45, estimateTolerance(bitmap, bounds, balloon.backgroundArgb))

        for (y in bounds.top until bounds.bottom) {
            var runStart = -1
            for (x in bounds.left until bounds.right) {
                val inside = mask.contains(x, y)
                val pixel = bitmap.getPixel(x, y)
                val compatiblePixel =
                    colorDistance(pixel, balloon.backgroundArgb) <= tolerance

                if (inside && compatiblePixel) {
                    if (runStart < 0) runStart = x
                } else if (runStart >= 0) {
                    compatible.op(
                        Region(runStart, y, x, y + 1),
                        compatible,
                        Region.Op.UNION
                    )
                    runStart = -1
                }
            }
            if (runStart >= 0) {
                compatible.op(
                    Region(runStart, y, bounds.right, y + 1),
                    compatible,
                    Region.Op.UNION
                )
            }
        }

        // Always retain the OCR area itself for text cleanup. The renderer
        // still clips it to the balloon shape.
        val cleanup = Region(
            max(bounds.left, textBounds.left - textBounds.width() / 4),
            max(bounds.top, textBounds.top - textBounds.height() / 4),
            min(bounds.right, textBounds.right + textBounds.width() / 4),
            min(bounds.bottom, textBounds.bottom + textBounds.height() / 4)
        )
        compatible.op(mask, Region.Op.INTERSECT)
        compatible.op(cleanup, Region.Op.UNION)

        return compatible
    }

    private fun estimateTolerance(bitmap: Bitmap, bounds: Rect, bg: Int): Int {
        val points = listOf(
            bounds.centerX() to bounds.top + bounds.height() / 4,
            bounds.centerX() to bounds.bottom - bounds.height() / 4,
            bounds.left + bounds.width() / 4 to bounds.centerY(),
            bounds.right - bounds.width() / 4 to bounds.centerY()
        )
        val distances = points.mapNotNull { (x, y) ->
            if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
                colorDistance(bitmap.getPixel(x, y), bg)
            } else null
        }
        val median = distances.sorted().getOrNull(distances.size / 2) ?: 40
        return (median + 35).coerceIn(45, 120)
    }

    private fun colorDistance(a: Int, b: Int): Int =
        abs(Color.red(a) - Color.red(b)) +
            abs(Color.green(a) - Color.green(b)) +
            abs(Color.blue(a) - Color.blue(b))
}
