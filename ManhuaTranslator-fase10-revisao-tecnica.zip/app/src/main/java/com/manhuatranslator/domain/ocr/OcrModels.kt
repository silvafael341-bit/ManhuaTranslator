package com.manhuatranslator.domain.ocr

import android.graphics.Rect

enum class OcrScript {
    LATIN,
    CHINESE,
    JAPANESE,
    KOREAN,
    UNKNOWN
}

data class OcrBlock(
    val text: String,
    val boundingBox: Rect,
    val confidence: Float?,
    val script: OcrScript,
    val angle: Int = 0
)

data class OcrPageResult(
    val blocks: List<OcrBlock>,
    val sourceWidth: Int,
    val sourceHeight: Int
)
