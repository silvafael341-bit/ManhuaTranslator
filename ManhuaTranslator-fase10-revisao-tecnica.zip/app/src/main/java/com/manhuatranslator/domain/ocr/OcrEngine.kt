package com.manhuatranslator.domain.ocr

import android.graphics.Bitmap

interface OcrEngine {
    suspend fun recognize(bitmap: Bitmap): OcrPageResult
    fun close()
}
