package com.manhuatranslator

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.manhuatranslator.domain.detection.DefaultTextRegionDetector
import com.manhuatranslator.domain.ocr.MlKitOcrEngine
import com.manhuatranslator.domain.ocr.OcrScript
import com.manhuatranslator.domain.pipeline.RegionTranslationService
import com.manhuatranslator.domain.rendering.TranslatedPageRenderer
import com.manhuatranslator.domain.translation.CachedTranslatorEngine
import com.manhuatranslator.domain.translation.MlKitTranslatorEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ManhuaTranslatorApp() }
    }
}

@Composable
fun ManhuaTranslatorApp() {
    var pages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var readerOpen by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            pages = uris
            readerOpen = true
        }
    }

    if (readerOpen && pages.isNotEmpty()) {
        ReaderScreen(
            pages = pages,
            onBack = { readerOpen = false }
        )
    } else {
        HomeScreen(
            pageCount = pages.size,
            onOpenImages = { picker.launch(arrayOf("image/*")) }
        )
    }
}

@Composable
private fun HomeScreen(
    pageCount: Int,
    onOpenImages: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Manhua Translator") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Leitor de Manhua", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "OCR + tradução offline + renderização em português.",
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onOpenImages) { Text("Abrir páginas") }
            if (pageCount > 0) {
                Spacer(Modifier.height(12.dp))
                Text("$pageCount página(s) selecionada(s)")
            }
        }
    }
}

@Composable
private fun ReaderScreen(
    pages: List<Uri>,
    onBack: () -> Unit
) {
    var currentPage by remember { mutableIntStateOf(0) }
    var translatedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var translating by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    fun translateCurrentPage() {
        if (translating) return

        scope.launch {
            translating = true
            translatedBitmap = null
            status = "Abrindo imagem..."

            try {
                val sourceBitmap = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(pages[currentPage]).use { input ->
                        BitmapFactory.decodeStream(input)
                            ?: error("Não foi possível abrir a imagem.")
                    }
                }

                status = "Executando OCR..."
                val ocr = MlKitOcrEngine()
                val ocrResult = try {
                    ocr.recognize(sourceBitmap)
                } finally {
                    ocr.close()
                }

                if (ocrResult.blocks.isEmpty()) {
                    status = "Nenhum texto detectado."
                    return@launch
                }

                status = "${ocrResult.blocks.size} bloco(s) detectado(s). Agrupando regiões..."
                val detector = DefaultTextRegionDetector()
                val regions = detector.detect(ocrResult.blocks)

                if (regions.isEmpty()) {
                    status = "Nenhuma região de texto válida."
                    return@launch
                }

                val sourceLanguage = when (ocrResult.script) {
                    OcrScript.CHINESE -> "zh"
                    OcrScript.JAPANESE -> "ja"
                    OcrScript.KOREAN -> "ko"
                    OcrScript.LATIN -> "en"
                    OcrScript.UNKNOWN -> null
                }

                if (sourceLanguage == null) {
                    status = "Não foi possível identificar o idioma da página."
                    return@launch
                }

                status = "${regions.size} região(ões). Preparando tradução..."
                val translator = CachedTranslatorEngine(MlKitTranslatorEngine())

                val translatedRegions = try {
                    RegionTranslationService(translator).translate(
                        regions = regions,
                        sourceLanguage = sourceLanguage,
                        targetLanguage = "pt"
                    )
                } finally {
                    translator.close()
                }

                val translatedCount = translatedRegions.count { it.translation != null }
                if (translatedCount == 0) {
                    status = "Nenhuma região foi traduzida."
                    return@launch
                }

                status = "Renderizando $translatedCount região(ões)..."
                val renderer = TranslatedPageRenderer()
                val rendered = withContext(Dispatchers.Default) {
                    renderer.renderPage(sourceBitmap, translatedRegions)
                }

                translatedBitmap = rendered.bitmap
                status = "${rendered.renderedRegions} região(ões) traduzida(s) na imagem." +
                    if (rendered.skippedRegions > 0) {
                        " ${rendered.skippedRegions} ignorada(s)."
                    } else {
                        ""
                    }
            } catch (e: Exception) {
                status = "Falha: ${e.message ?: "erro desconhecido"}"
            } finally {
                translating = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Página ${currentPage + 1} / ${pages.size}") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Voltar") }
                },
                actions = {
                    Button(
                        onClick = ::translateCurrentPage,
                        enabled = !translating
                    ) {
                        Text(if (translating) "Traduzindo..." else "Traduzir")
                    }
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = {
                        if (currentPage > 0) {
                            currentPage--
                            translatedBitmap = null
                            status = null
                        }
                    },
                    enabled = currentPage > 0 && !translating
                ) { Text("Anterior") }

                OutlinedButton(
                    onClick = {
                        if (currentPage < pages.lastIndex) {
                            currentPage++
                            translatedBitmap = null
                            status = null
                        }
                    },
                    enabled = currentPage < pages.lastIndex && !translating
                ) { Text("Próxima") }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            translatedBitmap?.let { bitmap ->
                ZoomableBitmap(
                    bitmap = bitmap,
                    modifier = Modifier.fillMaxSize()
                )
            } ?: ZoomableImage(
                uri = pages[currentPage],
                modifier = Modifier.fillMaxSize()
            )

            status?.let { message ->
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    tonalElevation = 4.dp
                ) {
                    Text(
                        text = message,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoomableImage(
    uri: Uri,
    modifier: Modifier = Modifier
) {
    var scale by remember(uri) { mutableFloatStateOf(1f) }
    var offset by remember(uri) { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(uri) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 5f)
                    offset += pan
                }
            },
        contentAlignment = Alignment.Center
    ) {
        coil3.compose.AsyncImage(
            model = uri,
            contentDescription = "Página do manhua",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        )
    }
}

@Composable
private fun ZoomableBitmap(
    bitmap: Bitmap,
    modifier: Modifier = Modifier
) {
    var scale by remember(bitmap) { mutableFloatStateOf(1f) }
    var offset by remember(bitmap) { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(bitmap) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 5f)
                    offset += pan
                }
            },
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Página traduzida",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        )
    }
}
