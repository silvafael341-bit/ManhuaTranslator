# Arquitetura do Manhua Translator

## Fluxo planejado

Imagem -> pré-processamento -> OCR -> TextBlock -> agrupamento/região
-> tradução -> layout -> máscara/remoção -> renderização -> leitor

## Regra de projeto

OCR, tradução, detecção e renderização permanecem desacoplados para que cada componente possa ser testado e substituído sem reescrever o restante do aplicativo.

## Fase 2

O leitor recebe `Uri` de imagens selecionadas pelo usuário. O conteúdo ainda não é alterado: o leitor apenas exibe a página original e oferece navegação e zoom.


## Renderização

`TranslatedPageRenderer` recebe a página e regiões traduzidas. Para cada região:
1. procura uma área de trabalho conservadora;
2. estima uma cor de fundo;
3. limpa somente a área detectada;
4. calcula quebra de linhas/tamanho de fonte;
5. centraliza a tradução;
6. registra regiões renderizadas e ignoradas.

A detecção atual é uma primeira versão. A próxima melhoria será uma máscara/contorno mais preciso para balões circulares e irregulares.
